package com.example.l4proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
